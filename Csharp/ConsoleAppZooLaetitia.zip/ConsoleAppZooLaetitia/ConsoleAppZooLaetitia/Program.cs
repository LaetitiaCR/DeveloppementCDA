﻿using ClassLibraryZoo;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsAppMyAppli.FoldZoo.MyLibrairieCLASSES;

namespace ConsoleAppTestZoo
{
    class Program
    {
        static void Main(string[] args)
        {
            DateTime dateNow = DateTime.Now;
            //AnimalDuZoo adz = new AnimalDuZoo(dateNow);

            Lion leo = new Lion(DateTime.Now);
            Perroquet coco = new Perroquet(DateTime.MinValue);
            int resu = leo.CompareTo(coco);

            List<AnimalDuZoo> mesAnimaux = new List<AnimalDuZoo>();
            mesAnimaux.Add(leo);
            //je vous laisse rajouter 2 autres animaux..

            mesAnimaux.Sort();

            //affichage ..il faut utiliser foreach et ToString()


            //collection de IDeplacable
            List<IDeplaceable> mesDeplacess = new List<IDeplaceable>();
            //il faut utiliser la methode Deplacer foreach

            //collection de IParlable




            
        }
    }
}
