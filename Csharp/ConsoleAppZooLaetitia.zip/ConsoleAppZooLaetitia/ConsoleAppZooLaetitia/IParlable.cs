﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsFormsAppMyAppli.FoldZoo.MyLibrairieCLASSES
{
    interface IParlable
    {
        void Parler();
       
    }
}
