﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WindowsFormsAppMyAppli.FoldZoo.MyLibrairieCLASSES
{
    interface IDeplaceable
    {
        void Deplacer();
        IDeplaceable NextDeplace();
    }
}
